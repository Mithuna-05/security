def generate_matrix(key):
    key = key.upper().replace("J", "I")
    chars = []
    for c in key + "ABCDEFGHIKLMNOPQRSTUVWXYZ":
        if c.isalpha() and c not in chars:
            chars.append(c)
    return [chars[i:i+5] for i in range(0, 25, 5)]

def preprocess(text):
    text = text.upper().replace("J", "I")
    text = "".join(c for c in text if c.isalpha())
    result = ""
    i = 0
    while i < len(text):
        a = text[i]
        b = text[i+1] if i+1 < len(text) else "X"
        if a == b:
            result += a + "X"
            i += 1
        else:
            result += a + b
            i += 2
    if len(result) % 2 != 0:
        result += "X"
    return result

def find_pos(matrix, ch):
    for i in range(5):
        for j in range(5):
            if matrix[i][j] == ch:
                return i, j

def playfair(text, matrix, mode):
    out = ""
    for i in range(0, len(text), 2):
        a, b = text[i], text[i+1]
        r1, c1 = find_pos(matrix, a)
        r2, c2 = find_pos(matrix, b)

        if r1 == r2:
            s = 1 if mode == "E" else -1
            out += matrix[r1][(c1+s)%5] + matrix[r2][(c2+s)%5]
        elif c1 == c2:
            s = 1 if mode == "E" else -1
            out += matrix[(r1+s)%5][c1] + matrix[(r2+s)%5][c2]
        else:
            out += matrix[r1][c2] + matrix[r2][c1]
    return out

# Main Program
key = input("Enter keyword: ")
matrix = generate_matrix(key)

print("Key Matrix:")
for row in matrix:
    print(*row)

plain = input("Enter plaintext: ")
plain = preprocess(plain)

cipher = playfair(plain, matrix, "E")
print("Encrypted:", cipher)

decrypted = playfair(cipher, matrix, "D")
print("Decrypted:", decrypted)