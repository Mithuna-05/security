# Hill Cipher 2x2

def mod_inverse(a):
    a = a % 26
    for i in range(1, 26):
        if (a * i) % 26 == 1:
            return i
    return None

def inverse_key(key):
    a, b = key[0]
    c, d = key[1]
    det = (a * d - b * c) % 26
    inv_det = mod_inverse(det)

    if inv_det is None:
        return None

    return [
        [(d * inv_det) % 26, (-b * inv_det) % 26],
        [(-c * inv_det) % 26, (a * inv_det) % 26]
    ]

def process(text):
    text = text.upper().replace(" ", "")
    if len(text) % 2 != 0:
        text += "X"
    return text

def hill(text, key):
    result = ""
    text = process(text)

    for i in range(0, len(text), 2):
        p1 = ord(text[i]) - 65
        p2 = ord(text[i+1]) - 65

        c1 = (key[0][0]*p1 + key[0][1]*p2) % 26
        c2 = (key[1][0]*p1 + key[1][1]*p2) % 26

        result += chr(c1 + 65) + chr(c2 + 65)
    return result

# Input
print("Enter 2x2 key matrix:")
key = [
    list(map(int, input().split())),
    list(map(int, input().split()))
]

plaintext = input("Enter plaintext: ")

cipher = hill(plaintext, key)
print("Encrypted:", cipher)

inv = inverse_key(key)
if inv:
    decrypted = hill(cipher, inv)
    print("Decrypted:", decrypted)
else:
    print("Key matrix is not invertible.")