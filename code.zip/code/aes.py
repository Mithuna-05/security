from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

# Input
plaintext = input("Enter plaintext: ")
key = input("Enter 16-byte key: ").encode()

# Ensure key is exactly 16 bytes
key = key[:16].ljust(16, b'X')

# Create AES cipher (ECB Mode)
cipher = AES.new(key, AES.MODE_ECB)

# Encryption
ciphertext = cipher.encrypt(pad(plaintext.encode(), AES.block_size))

print("Plaintext :", plaintext)
print("Secret Key:", key.decode())
print("Ciphertext (Hex):", ciphertext.hex())

# Decryption
decrypted = unpad(cipher.decrypt(ciphertext), AES.block_size).decode()
print("Decrypted Plaintext:", decrypted)