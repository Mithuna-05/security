import math

def create_matrix(rows, cols):
    return [['X' for _ in range(cols)] for _ in range(rows)]

def display(mat):
    for row in mat:
        print(" ".join(row))

# Row Major Encryption
def row_encrypt(text, cols):
    text = text.upper().replace(" ", "")
    rows = math.ceil(len(text) / cols)
    mat = create_matrix(rows, cols)

    k = 0
    for c in range(cols):
        for r in range(rows):
            if k < len(text):
                mat[r][c] = text[k]
                k += 1

    cipher = ""
    for r in range(rows):
        for c in range(cols):
            cipher += mat[r][c]
    return cipher, mat

def row_decrypt(cipher, cols):
    rows = len(cipher) // cols
    mat = create_matrix(rows, cols)

    k = 0
    for r in range(rows):
        for c in range(cols):
            mat[r][c] = cipher[k]
            k += 1

    text = ""
    for c in range(cols):
        for r in range(rows):
            text += mat[r][c]
    return text.rstrip("X")

# Column Major Encryption
def column_encrypt(text, cols):
    text = text.upper().replace(" ", "")
    rows = math.ceil(len(text) / cols)
    mat = create_matrix(rows, cols)

    k = 0
    for r in range(rows):
        for c in range(cols):
            if k < len(text):
                mat[r][c] = text[k]
                k += 1

    cipher = ""
    for c in range(cols):
        for r in range(rows):
            cipher += mat[r][c]
    return cipher, mat

def column_decrypt(cipher, cols):
    rows = len(cipher) // cols
    mat = create_matrix(rows, cols)

    k = 0
    for c in range(cols):
        for r in range(rows):
            mat[r][c] = cipher[k]
            k += 1

    text = ""
    for r in range(rows):
        for c in range(cols):
            text += mat[r][c]
    return text.rstrip("X")

# Main
plain = input("Enter plaintext: ")
cols = int(input("Enter number of columns: "))

# Row Major
rc, rmat = row_encrypt(plain, cols)
print("\nRow Major Matrix:")
display(rmat)
print("Row Major Ciphertext:", rc)
print("Decrypted:", row_decrypt(rc, cols))

# Column Major
cc, cmat = column_encrypt(plain, cols)
print("\nColumn Major Matrix:")
display(cmat)
print("Column Major Ciphertext:", cc)
print("Decrypted:", column_decrypt(cc, cols))