from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

# Generate 2048-bit RSA key pair
key = RSA.generate(2048)
public_key = key.publickey()

# Input
plaintext = input("Enter plaintext: ")

# Encrypt using public key
cipher = PKCS1_OAEP.new(public_key)
ciphertext = cipher.encrypt(plaintext.encode())

# Display
print("\nPublic Key:\n", public_key.export_key().decode())
print("\nPrivate Key:\n", key.export_key().decode())
print("\nPlaintext:", plaintext)
print("Ciphertext (Hex):", ciphertext.hex())

# Decrypt using private key
decipher = PKCS1_OAEP.new(key)
decrypted = decipher.decrypt(ciphertext).decode()

print("Decrypted Plaintext:", decrypted)