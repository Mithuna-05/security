def encrypt(text, key):
    result = ""
    for ch in text:
        if ch.isalpha():
            shift = 65 if ch.isupper() else 97
            result += chr((ord(ch) - shift + key) % 26 + shift)
        else:
            result += ch
    return result

def decrypt(text, key):
    return encrypt(text, -key)

def brute_force(text):
    for key in range(26):
        print("Key", key, ":", decrypt(text, key))

while True:
    print("\n1. Encrypt")
    print("2. Decrypt")
    print("3. Brute Force Attack")
    print("4. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        text = input("Enter text: ")
        key = int(input("Enter key: "))
        print("Encrypted:", encrypt(text, key))

    elif choice == "2":
        text = input("Enter cipher text: ")
        key = int(input("Enter key: "))
        print("Decrypted:", decrypt(text, key))

    elif choice == "3":
        text = input("Enter cipher text: ")
        brute_force(text)

    elif choice == "4":
        print("Exiting...")
        break

    else:
        print("Invalid choice!")