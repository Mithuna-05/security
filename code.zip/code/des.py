#pip install pycryptodome

from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad

# Input
plaintext = input("Enter plaintext: ")
key = input("Enter 8-byte key: ").encode()

# Ensure key is exactly 8 bytes
key = key[:8].ljust(8, b'X')

# Create DES cipher
cipher = DES.new(key, DES.MODE_ECB)

# Encryption
encrypted = cipher.encrypt(pad(plaintext.encode(), 8))
print("Plaintext :", plaintext)
print("Secret Key:", key.decode())
print("Ciphertext (Hex):", encrypted.hex())

# Decryption
decrypted = unpad(cipher.decrypt(encrypted), 8).decode()
print("Decrypted :", decrypted)